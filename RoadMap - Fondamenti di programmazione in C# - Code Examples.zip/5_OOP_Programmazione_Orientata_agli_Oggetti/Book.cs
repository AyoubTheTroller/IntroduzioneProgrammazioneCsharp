public class Book
{
    public string? Title { get; set; }
    public string? Author { get; set; }
    // Other book details
}