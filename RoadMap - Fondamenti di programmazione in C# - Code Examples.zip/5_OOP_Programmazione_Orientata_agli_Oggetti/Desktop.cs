public class Desktop : Computer{
    public override void Start()
    {
        Console.WriteLine("Starting the desktop...");
    }
}