public abstract class Computer{
    public abstract void Start();
}