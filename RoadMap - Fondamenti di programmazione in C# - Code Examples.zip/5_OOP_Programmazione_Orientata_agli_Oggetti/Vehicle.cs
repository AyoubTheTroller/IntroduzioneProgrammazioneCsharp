public class Vehicle {
    public string? Brand { get; set; }
}