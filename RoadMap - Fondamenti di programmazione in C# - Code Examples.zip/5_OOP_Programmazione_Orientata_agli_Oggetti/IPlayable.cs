public interface IPlayable{
    void PlayGame(string gameName);
}